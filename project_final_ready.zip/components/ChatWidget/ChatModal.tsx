export default function ChatModal() {
  return null
}
